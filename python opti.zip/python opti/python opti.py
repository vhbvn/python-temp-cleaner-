import os
import shutil
import tempfile

def clean_temp_files():
    temp_dir = tempfile.gettempdir()
    print(f"Cleaning temp directory: {temp_dir}")
    
    try:
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                try:
                    file_path = os.path.join(root, file)
                    os.remove(file_path)
                    print(f"Deleted file: {file_path}")
                except Exception as e:
                    print(f"Failed to delete file: {file_path}. Reason: {e}")
            
            for dir in dirs:
                try:
                    dir_path = os.path.join(root, dir)
                    shutil.rmtree(dir_path)
                    print(f"Deleted directory: {dir_path}")
                except Exception as e:
                    print(f"Failed to delete directory: {dir_path}. Reason: {e}")
        
        print("Temp files cleaned.")
    except Exception as e:
        print(f"Failed to clean temp directory: {e}")

def clean_cache():
    cache_dirs = [
        os.path.expanduser('~\\AppData\\Local\\Microsoft\\Windows\\INetCache'),
        os.path.expanduser('~\\AppData\\Local\\Microsoft\\Windows\\Explorer'),
        os.path.expanduser('~\\AppData\\Local\\Microsoft\\Windows\\WebCache'),
        os.path.expanduser('~\\AppData\\Local\\Google\\Chrome\\User Data\\Default\\Cache'),
        os.path.expanduser('~\\AppData\\Local\\Mozilla\\Firefox\\Profiles')
    ]
    
    print("Cleaning cache directories...")

    for cache_dir in cache_dirs:
        if os.path.exists(cache_dir):
            try:
                shutil.rmtree(cache_dir)
                print(f"Deleted cache directory: {cache_dir}")
            except Exception as e:
                print(f"Failed to delete cache directory: {cache_dir}. Reason: {e}")
        else:
            print(f"Cache directory not found: {cache_dir}")

    print("Cache cleaned.")

def main():
    print("Enter 1 to clean temp files and cache:")
    user_input = input()

    if user_input == "1":
        clean_temp_files()
        clean_cache()
    else:
        print("Invalid input. Exiting...")

if __name__ == "__main__":
    main()
